﻿using DemoEmsv2024August24.Model;
using DemoEmsv2024August24.ViewModel;
using Microsoft.AspNetCore.Mvc;

namespace DemoEmsv2024August24.Repository
{
    public interface IEmployeeRepository
    {
        #region 1-Get all employees
        public Task<ActionResult<IEnumerable<TblEmployee>>> GetTblEmployees();

        #endregion

        #region 2- Get All employees using ViewModel

        public Task<ActionResult<IEnumerable<EmpDeptViewModel>>> GetViewModelEmployees();


        #endregion

        #region -3 Get an employee based on id

        //Get an Employee based on Id
        public Task<ActionResult<TblEmployee>> GetTblEmployeesById(int id);
        #endregion

    }
}
