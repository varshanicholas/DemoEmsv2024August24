﻿using DemoEmsv2024August24.Model;
using DemoEmsv2024August24.ViewModel;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace DemoEmsv2024August24.Repository
{
    public class EmployeeRepository : IEmployeeRepository
    {
        //EF--VirtualDatabase

        private readonly DemoAugust2024DbContext _context;

        //DI -Constructor injection

        public EmployeeRepository(DemoAugust2024DbContext context )
        {
            _context = context;
        }

        #region -1 Get all employees


        public async  Task<ActionResult<IEnumerable<TblEmployee>>> GetTblEmployees()
        {
            try
            {
                if(_context != null)
                {
                  return  await _context.TblEmployees.Include(emp=>emp.Department).ToListAsync ();
                }
                //return an empty list if context is null
                return new List<TblEmployee> ();
            }
            catch(Exception ex) 
            {
                return null;
            }
        }

        
        #endregion


        #region -2 Get all Using ViewModel

        public async  Task<ActionResult<IEnumerable<EmpDeptViewModel>>> GetViewModelEmployees()
        {
            try
            {
                if (_context != null)
                {
                    /*
                     Select e.EmployeeId,e.EmpName,d.DepartmentName
                      From TblEmployees e
                      Join TblDepartments d
                      ON e.DepartmentId=d.DepartmentId
                     */
                    return await(from e in _context.TblEmployees
                                 from d in _context.TblDepartments
                                 where e.DepartmentId == d.DepartmentId
                                 select new EmpDeptViewModel
                                 {
                                     EmployeeId = e.EmployeeId,
                                     EmployeeName = e.EmployeeName,
                                     Designation = e.Designation,
                                     DepartmentName = d.DepartmentName,
                                     Contact = e.Contact
                                 }).ToListAsync();
                }
                //return an empty list if context is null
                return new List<EmpDeptViewModel>();
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        #endregion


        #region -3 get employee details based on id

        public async Task<ActionResult<TblEmployee>> GetTblEmployeesById(int id)
        {
            try
            {
                if(_context!= null)
                {
                    //find the employee by id 

                    var employee=await _context .TblEmployees 
                        .Include (emp=>emp.Department)
                        .FirstOrDefaultAsync (e=>e.EmployeeId == id);
                    return employee;
                }

                return null;

            }

            catch(Exception ex)
            {
                return null;
            }
        }

        
        #endregion
    }
}
