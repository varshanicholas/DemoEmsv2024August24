﻿using DemoEmsv2024August24.Model;
using DemoEmsv2024August24.Repository;
using DemoEmsv2024August24.ViewModel;
using Microsoft.AspNetCore.Mvc;
using Microsoft.CodeAnalysis.CSharp.Syntax;
using NuGet.Protocol.Core.Types;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace DemoEmsv2024August24.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EmployeesController : ControllerBase
    {
        //call repository

        private readonly IEmployeeRepository _repository;


        //Dependency injuction DI ---Constructor Instrucor

        public EmployeesController(IEmployeeRepository repository)
        {
            _repository = repository;
        }

/*
        // GET: api/Employees
        [HttpGet]
        public IEnumerable<string> Get()
        {
            return new string[] { "varsha", "ahalya","tharak" };
        }
*/
        // GET api/Employees/5
        [HttpGet("{id}")]
        public string Get(int id)
        {
            return "value "+id;
        }

        #region 1- get all employees-search all
        [HttpGet]
        public async Task<ActionResult<IEnumerable <TblEmployee>>> GetAllEmployees()
        {
            var employees=await _repository .GetTblEmployees ();
            if(employees == null)
            {
                return NotFound ("No Employees found");
            }

            return Ok (employees);
        }

        #endregion

        #region 2- get all employees-search all
        [HttpGet ("vm")]
        public async Task<ActionResult<IEnumerable<EmpDeptViewModel>>> GetAllEmployeesByViewModel()
        {
            var employees = await _repository.GetViewModelEmployees ();
            if (employees == null)
            {
                return NotFound("No Employees found");
            }

            return Ok(employees);
        }

        #endregion

        #region 3- get all employees-search by id
        [HttpGet("{id}")]
        public async Task<ActionResult<EmpDeptViewModel>> GetEmployeesById(int id)
        {
            var employees = await _repository.GetTblEmployeesById(id);
            if (employees == null)
            {
                return NotFound("No Employees found");
            }

            return Ok(employees);
        }

        #endregion

        //// POST api/<EmployeesController>
        //[HttpPost]
        //public void Post([FromBody] string value)
        //{
        //}

        //// PUT api/<EmployeesController>/5
        //[HttpPut("{id}")]
        //public void Put(int id, [FromBody] string value)
        //{
        //}

        //// DELETE api/<EmployeesController>/5
        //[HttpDelete("{id}")]
        //public void Delete(int id)
        //{
        //}
    }
}
