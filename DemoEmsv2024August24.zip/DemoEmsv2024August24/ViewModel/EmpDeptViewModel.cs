﻿namespace DemoEmsv2024August24.ViewModel
{
    public class EmpDeptViewModel
    {
        public int EmployeeId { get; set; }
        public string EmployeeName { get; set; }
        public string Designation { get; set; }
        public string Contact { get; set; }
        public string DepartmentName { get; set; }
    }
}
